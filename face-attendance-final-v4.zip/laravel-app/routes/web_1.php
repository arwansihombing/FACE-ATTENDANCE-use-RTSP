<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\StaffLoginController;
use App\Http\Controllers\Operator\OperatorDashboardController;
use App\Http\Controllers\Admin\StudentImportController;
use App\Http\Controllers\Admin\StudentEnrollController;
use App\Http\Controllers\IT\DashboardController as ITDashboard;
use App\Http\Controllers\IT\CameraController as ITCamera;

Route::get('/', fn()=> redirect('/login'));
Route::get('/login',[StaffLoginController::class,'show'])->name('login');
Route::post('/login',[StaffLoginController::class,'login']);
Route::post('/logout',[StaffLoginController::class,'logout'])->name('logout');

Route::prefix('operator')->name('operator.')->group(function(){
  Route::get('/login',fn()=> view('auth.operator-login'))->name('login');
  Route::post('/login', [\App\Http\Controllers\Operator\SelectGateController::class,'login'])->name('login.attempt');
  Route::middleware('operator.auth')->group(function(){
    Route::get('/',[OperatorDashboardController::class,'index'])->name('dashboard');
    Route::get('/queue',[OperatorDashboardController::class,'callQueue']);
  });
});

Route::middleware(['auth','role:admin'])->prefix('admin')->name('admin.')->group(function(){
  Route::get('/',fn()=> view('admin.dashboard'))->name('dashboard');
  // Import
  Route::get('/students/import',[StudentImportController::class,'show'])->name('students.import.show');
  Route::post('/students/import',[StudentImportController::class,'import'])->name('students.import');
  Route::get('/students/template',[StudentImportController::class,'template'])->name('students.template');
  // Enroll
  Route::get('/students/enroll',[StudentEnrollController::class,'index'])->name('students.enroll.index');
  Route::get('/students/enroll/stats',[StudentEnrollController::class,'bulkEnrollStatus'])->name('students.enroll.stats');
  Route::get('/students/{student}/enroll',[StudentEnrollController::class,'capturePage'])->name('students.enroll.page');
  Route::post('/students/{student}/enroll',[StudentEnrollController::class,'enroll'])->name('students.enroll.store');
});

Route::middleware(['auth','role:it'])->prefix('it')->name('it.')->group(function(){
  Route::get('/',[ITDashboard::class,'index'])->name('dashboard');
  Route::get('/dashboard/cameras',[ITDashboard::class,'camerasJson'])->name('dashboard.cameras');
  Route::get('/cameras',[ITCamera::class,'index'])->name('cameras.index');
  Route::post('/cameras',[ITCamera::class,'store'])->name('cameras.store');
  Route::post('/cameras/{camera}/toggle',[ITDashboard::class,'toggle'])->name('cameras.toggle');
  Route::delete('/cameras/{camera}',[ITCamera::class,'destroy'])->name('cameras.destroy');
  Route::post('/cameras/{camera}/test',[ITCamera::class,'test'])->name('cameras.test');
});

Route::middleware(['auth','role:guru_bk'])->prefix('guru-bk')->group(fn()=> Route::get('/',fn()=> view('guru-bk.dashboard')));
Route::middleware(['auth','role:kepsek'])->prefix('kepsek')->group(fn()=> Route::get('/',fn()=> view('kepsek.dashboard')));

Route::prefix('internal')->middleware('internal.auth')->group(function(){
  Route::post('/heartbeat',[\App\Http\Controllers\Internal\HeartbeatController::class,'store']);
  Route::post('/attendance',[\App\Http\Controllers\Internal\AttendanceController::class,'store']);
});

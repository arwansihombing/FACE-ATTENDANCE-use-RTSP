<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\StaffLoginController;
use App\Http\Controllers\Operator\OperatorDashboardController;

Route::get('/', fn()=> redirect('/login'));
Route::get('/login',[StaffLoginController::class,'show'])->name('login');
Route::post('/login',[StaffLoginController::class,'login']);
Route::post('/logout',[StaffLoginController::class,'logout'])->name('logout');

Route::prefix('operator')->name('operator.')->group(function(){
  Route::get('/login',fn()=> view('auth.operator-login'))->name('login');
  Route::post('/login', [\App\Http\Controllers\Operator\SelectGateController::class,'login'])->name('login.attempt');
  Route::middleware('operator.auth')->group(function(){
    Route::get('/',[OperatorDashboardController::class,'index'])->name('dashboard');
    Route::get('/queue',[OperatorDashboardController::class,'callQueue']);
  });
});

Route::middleware(['auth','role:admin'])->prefix('admin')->group(fn()=> Route::get('/',fn()=> view('admin.dashboard')));
Route::middleware(['auth','role:it'])->prefix('it')->group(fn()=> Route::get('/',fn()=> view('it.dashboard')));
Route::middleware(['auth','role:guru_bk'])->prefix('guru-bk')->group(fn()=> Route::get('/',fn()=> view('guru-bk.dashboard')));
Route::middleware(['auth','role:kepsek'])->prefix('kepsek')->group(fn()=> Route::get('/',fn()=> view('kepsek.dashboard')));

Route::prefix('internal')->middleware('internal.auth')->group(function(){
  Route::post('/heartbeat',[\App\Http\Controllers\Internal\HeartbeatController::class,'store']);
  Route::post('/attendance',[\App\Http\Controllers\Internal\AttendanceController::class,'store']);
});

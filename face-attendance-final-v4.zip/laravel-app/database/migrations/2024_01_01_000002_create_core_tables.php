<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema; use Illuminate\Support\Facades\DB;
return new class extends Migration {
 public function up(): void {
  Schema::create('gates',function(Blueprint $t){ $t->id(); $t->string('name'); $t->string('location')->nullable(); $t->boolean('is_active')->default(true); $t->timestamps(); });
  Schema::create('cameras',function(Blueprint $t){
   $t->id(); $t->foreignId('gate_id')->constrained('gates')->cascadeOnDelete();
   $t->string('name'); $t->string('rtsp_url'); $t->boolean('is_active')->default(true);
   $t->string('status')->default('offline'); $t->timestamp('last_heartbeat_at')->nullable(); $t->timestamps();
  });
  Schema::create('levels',function(Blueprint $t){ $t->id(); $t->string('name'); $t->timestamps(); });
  Schema::create('majors',function(Blueprint $t){ $t->id(); $t->string('name'); $t->timestamps(); });
  Schema::create('school_classes',function(Blueprint $t){
   $t->id(); $t->foreignId('level_id')->constrained('levels'); $t->foreignId('major_id')->constrained('majors');
   $t->string('name'); $t->timestamps();
  });
  Schema::create('students',function(Blueprint $t){
   $t->id(); $t->string('nisn')->unique(); $t->string('name'); $t->foreignId('school_class_id')->constrained('school_classes');
   $t->string('photo_path')->nullable(); $t->integer('embedding_version')->default(1); $t->boolean('is_active')->default(true); $t->timestamps();
  });
  // pgvector column via raw
  DB::statement('ALTER TABLE students ADD COLUMN face_embedding vector(512)');
  DB::statement('CREATE INDEX ON students USING hnsw (face_embedding vector_cosine_ops) WITH (m=16, ef_construction=200)');

  Schema::create('operators',function(Blueprint $t){
   $t->id(); $t->string('name'); $t->string('username')->unique(); $t->string('password');
   $t->foreignId('gate_id')->nullable()->constrained('gates'); $t->boolean('is_active')->default(true); $t->timestamps();
  });
  Schema::create('attendances',function(Blueprint $t){
   $t->id(); $t->foreignId('student_id')->constrained('students'); $t->foreignId('gate_id')->nullable()->constrained('gates');
   $t->foreignId('camera_id')->nullable()->constrained('cameras'); $t->enum('status',['present','late','early','absent','review']);
   $t->float('confidence')->default(0); $t->integer('late_minutes')->default(0);
   $t->string('snapshot_path')->nullable(); $t->timestamp('verified_at')->nullable(); $t->date('date'); $t->timestamps();
   $t->unique(['student_id','date']); $t->index(['gate_id','date']);
  });
  Schema::create('audit_logs',function(Blueprint $t){
   $t->id(); $t->string('user_type'); $t->unsignedBigInteger('user_id')->nullable();
   $t->string('action'); $t->json('payload')->nullable(); $t->string('ip')->nullable(); $t->timestamps();
  });
 }
 public function down(): void {
  Schema::dropIfExists('audit_logs'); Schema::dropIfExists('attendances'); Schema::dropIfExists('operators'); Schema::dropIfExists('students'); Schema::dropIfExists('school_classes'); Schema::dropIfExists('majors'); Schema::dropIfExists('levels'); Schema::dropIfExists('cameras'); Schema::dropIfExists('gates');
 }
};

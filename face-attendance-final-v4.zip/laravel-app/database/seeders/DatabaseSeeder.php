<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder; use App\Models\User; use App\Models\Gate; use App\Enums\StaffRole; use Illuminate\Support\Facades\Hash;
class DatabaseSeeder extends Seeder {
  public function run(): void {
    User::create(['name'=>'Admin','email'=>'admin@sekolah.test','password'=>Hash::make('password'),'role'=>StaffRole::Admin]);
    User::create(['name'=>'IT','email'=>'it@sekolah.test','password'=>Hash::make('password'),'role'=>StaffRole::IT]);
    Gate::create(['name'=>'Gerbang A','location'=>'Depan']);
    Gate::create(['name'=>'Gerbang B','location'=>'Belakang']);
    \App\Models\Operator::create(['name'=>'Operator A','username'=>'operator_a','password'=>Hash::make('op123456'),'gate_id'=>1]);
  }
}

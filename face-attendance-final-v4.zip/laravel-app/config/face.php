<?php
return [
  'accept'=> env('FACE_CONF_ACCEPT',0.60),
  'review'=> env('FACE_CONF_REVIEW',0.45),
  'version'=> env('FACE_EMBED_VERSION',1),
];

@extends('layouts.cms')
@section('title','IT Monitoring')
@section('content')
<div class="max-w-7xl mx-auto space-y-6">
  <div class="flex justify-between items-center">
    <h1 class="text-3xl font-bold">🖥️ IT Realtime Monitoring v2</h1>
    <div class="flex gap-2">
      <span class="bg-black text-white px-4 py-2 rounded-full text-sm" id="clock">--:--:--</span>
      <a href="{{ route('it.cameras.index') }}" class="bg-white border px-4 py-2 rounded-xl text-sm">Kelola Kamera</a>
    </div>
  </div>

  <!-- Stats Cards -->
  <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
    <div class="bg-white p-5 rounded-2xl shadow"><div class="text-xs text-gray-500">Total Kamera</div><div class="text-3xl font-black">{{ $stats['total_cameras'] }}</div></div>
    <div class="bg-green-50 p-5 rounded-2xl shadow border border-green-200"><div class="text-xs text-green-700">Online</div><div class="text-3xl font-black text-green-600">{{ $stats['online'] }}</div></div>
    <div class="bg-red-50 p-5 rounded-2xl shadow border border-red-200"><div class="text-xs text-red-700">Offline/Stale</div><div class="text-3xl font-black text-red-600">{{ $stats['stale'] }}</div></div>
    <div class="bg-blue-50 p-5 rounded-2xl shadow border border-blue-200"><div class="text-xs text-blue-700">Antrian Panggil</div><div class="text-3xl font-black text-blue-600" id="queue-len">{{ $stats['queue'] }}</div></div>
    <div class="bg-purple-50 p-5 rounded-2xl shadow border border-purple-200"><div class="text-xs text-purple-700">Absen Hari Ini</div><div class="text-3xl font-black text-purple-600">{{ $stats['today'] }}</div></div>
  </div>

  <!-- Cameras Grid Realtime -->
  <div class="bg-white rounded-2xl shadow p-6">
    <div class="flex justify-between mb-4"><h2 class="font-bold text-lg">Status Kamera Realtime</h2><button onclick="refreshCams()" class="text-sm border px-3 py-1 rounded-lg">↻ Refresh</button></div>
    <div id="cameras-grid" class="grid md:grid-cols-3 gap-4"></div>
  </div>

  <!-- Gates -->
  <div class="bg-white rounded-2xl shadow p-6">
    <h2 class="font-bold mb-3">Gerbang</h2>
    <div class="flex gap-3 flex-wrap">
      @foreach($gates as $g)
        <div class="border rounded-xl px-4 py-2 text-sm">{{ $g->name }} - {{ $g->cameras_count }} kamera - {{ $g->location }}</div>
      @endforeach
    </div>
  </div>

  <!-- Live Logs -->
  <div class="bg-gray-900 text-green-400 rounded-2xl p-4 font-mono text-xs h-64 overflow-y-auto" id="live-log">Waiting for events... (Reverb channel: gate.*)</div>
</div>

<script>
function refreshCams(){
  fetch('{{ route('it.dashboard.cameras') }}').then(r=>r.json()).then(data=>{
    const grid=document.getElementById('cameras-grid');
    grid.innerHTML=data.map(c=>`
      <div class="border rounded-2xl p-4 ${c.stale?'border-red-300 bg-red-50':'border-green-300 bg-green-50'}">
        <div class="flex justify-between"><span class="font-bold">${c.name}</span><span class="text-xs px-2 py-1 rounded-full ${c.status=='online'?'bg-green-600 text-white':'bg-red-600 text-white'}">${c.status}</span></div>
        <div class="text-xs text-gray-600 mt-1">${c.gate} • ${c.last_heartbeat || 'belum pernah heartbeat'}</div>
        <div class="text-[10px] text-gray-400 mt-1">${c.rtsp}</div>
        <div class="mt-2 flex gap-2">
          <a href="#" class="text-xs bg-black text-white px-2 py-1 rounded">Test</a>
          <span class="text-xs">${c.is_active?'Aktif':'Nonaktif'}</span>
        </div>
      </div>
    `).join('');
  });
}
refreshCams(); setInterval(refreshCams,5000);
setInterval(()=>{ document.getElementById('clock').innerText=new Date().toLocaleTimeString('id-ID'); },1000);

// Reverb listener (Laravel Echo)
document.addEventListener('DOMContentLoaded', ()=>{
  const log=document.getElementById('live-log');
  try{
    if(window.Echo){
      window.Echo.channel('gate.1').listen('StudentVerified',(e)=>{
        const line=`[${new Date().toLocaleTimeString()}] Siswa terverifikasi: ${e.student} (ID:${e.id})`;
        log.innerHTML=line+'<br>'+log.innerHTML;
      });
    }
  }catch(err){ log.innerHTML='Echo belum connect: '+err.message; }
});
</script>
@endsection

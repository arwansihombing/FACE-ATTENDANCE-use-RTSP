@extends('layouts.cms')
@section('title','Kelola Kamera')
@section('content')
<div class="max-w-6xl mx-auto space-y-6">
  <h1 class="text-2xl font-bold">Kelola Kamera RTSP</h1>
  @if(session('success'))<div class="bg-green-100 p-3 rounded-xl">{{ session('success') }}</div>@endif

  <div class="bg-white p-6 rounded-2xl shadow">
    <h2 class="font-bold mb-3">Tambah Kamera Baru</h2>
    <form method="POST" action="{{ route('it.cameras.store') }}" class="grid md:grid-cols-4 gap-3">
      @csrf
      <select name="gate_id" class="border p-2.5 rounded-xl" required>
        @foreach($gates as $g)<option value="{{ $g->id }}">{{ $g->name }}</option>@endforeach
      </select>
      <input name="name" placeholder="Nama Kamera (ex: Gerbang A - Cam 1)" class="border p-2.5 rounded-xl" required>
      <input name="rtsp_url" placeholder="rtsp://admin:pass@192.168.1.10/stream" class="border p-2.5 rounded-xl" required>
      <button class="bg-black text-white rounded-xl">+ Tambah</button>
    </form>
  </div>

  <div class="bg-white rounded-2xl shadow overflow-hidden">
    <table class="w-full text-sm">
      <thead class="bg-gray-50 text-xs text-gray-500"><tr><th class="p-3 text-left">Nama</th><th>Gerbang</th><th>RTSP</th><th>Status</th><th>Last Heartbeat</th><th>Aksi</th></tr></thead>
      <tbody>
        @foreach($cameras as $c)
        <tr class="border-t">
          <td class="p-3 font-semibold">{{ $c->name }}</td>
          <td>{{ $c->gate->name ?? '-' }}</td>
          <td class="text-xs text-gray-500 truncate max-w-[200px]">{{ $c->rtsp_url }}</td>
          <td><span class="px-2 py-1 rounded-full text-xs {{ $c->status=='online'?'bg-green-100 text-green-700':'bg-red-100 text-red-700' }}">{{ $c->status }}</span></td>
          <td class="text-xs">{{ $c->last_heartbeat_at?->diffForHumans() ?? '-' }}</td>
          <td class="flex gap-1 p-2">
            <form method="POST" action="{{ route('it.cameras.toggle',$c) }}">@csrf<button class="text-xs border px-2 py-1 rounded">Toggle</button></form>
            <form method="POST" action="{{ route('it.cameras.destroy',$c) }}">@csrf @method('DELETE')<button class="text-xs bg-red-600 text-white px-2 py-1 rounded">Hapus</button></form>
          </td>
        </tr>
        @endforeach
      </tbody>
    </table>
    <div class="p-3">{{ $cameras->links() }}</div>
  </div>
</div>
@endsection

@extends('layouts.cms')
@section('title','Import Siswa')
@section('content')
<div class="max-w-5xl mx-auto space-y-6">
  <div class="flex justify-between items-center">
    <h1 class="text-2xl font-bold">Import Siswa Excel</h1>
    <a href="{{ route('admin.students.template') }}" class="bg-green-600 text-white px-4 py-2 rounded-xl text-sm">📥 Download Template</a>
  </div>

  @if(session('success'))<div class="bg-green-100 border border-green-300 text-green-800 p-3 rounded-xl">{{ session('success') }}</div>@endif

  <div class="bg-white p-6 rounded-2xl shadow">
    <form method="POST" action="{{ route('admin.students.import') }}" enctype="multipart/form-data" class="space-y-4">
      @csrf
      <div>
        <label class="font-semibold">Pilih Kelas Tujuan</label>
        <select name="school_class_id" class="w-full border p-3 rounded-xl mt-1" required>
          <option value="">-- Pilih Kelas --</option>
          @foreach($classes as $c)
            <option value="{{ $c->id }}">{{ $c->level->name ?? '' }} {{ $c->major->name ?? '' }} - {{ $c->name }}</option>
          @endforeach
        </select>
      </div>
      <div>
        <label class="font-semibold">File Excel (xlsx, max 5MB)</label>
        <input type="file" name="file" accept=".xlsx,.xls,.csv" class="w-full border p-3 rounded-xl mt-1" required>
        <p class="text-xs text-gray-500 mt-1">Kolom wajib: nisn (10 digit), nama</p>
      </div>
      <button class="bg-black text-white px-6 py-3 rounded-xl w-full font-semibold">Upload & Import</button>
    </form>
  </div>

  @if(session('import_failures'))
  <div class="bg-yellow-50 border border-yellow-300 p-4 rounded-xl">
    <h3 class="font-bold text-yellow-800">Beberapa baris gagal:</h3>
    <ul class="text-sm mt-2 list-disc ml-5">
      @foreach(session('import_failures') as $f)
        <li>Baris {{ $f->row() }}: {{ implode(', ', $f->errors()) }} ({{ $f->values()['nisn'] ?? '' }})</li>
      @endforeach
    </ul>
  </div>
  @endif

  <div class="bg-blue-50 p-4 rounded-xl text-sm text-blue-800">
    <b>Cara pakai:</b> 1) Download template, 2) Isi NISN & Nama, 3) Pilih kelas tujuan, 4) Upload. NISN harus unik, tidak boleh dobel.
  </div>
</div>
@endsection

@extends('layouts.cms')
@section('title','Enroll Wajah')
@section('content')
<div class="max-w-6xl mx-auto space-y-6" x-data="{ search: '' }">
  <div class="flex justify-between">
    <h1 class="text-2xl font-bold">Enroll Wajah - Belum Terdaftar</h1>
    <div class="flex gap-2">
      <span id="enroll-stats" class="bg-gray-900 text-white px-4 py-2 rounded-xl text-sm">Loading...</span>
      <a href="{{ route('admin.dashboard') }}" class="bg-white border px-4 py-2 rounded-xl">Dashboard</a>
    </div>
  </div>

  <div class="bg-white p-4 rounded-2xl shadow flex gap-3">
    <form method="GET" class="flex gap-2 w-full">
      <input name="search" value="{{ request('search') }}" placeholder="Cari nama / NISN..." class="flex-1 border p-2.5 rounded-xl">
      <button class="bg-black text-white px-5 rounded-xl">Cari</button>
    </form>
  </div>

  <div class="grid md:grid-cols-3 gap-4">
    @foreach($students as $s)
    <div class="bg-white rounded-2xl shadow p-4 flex gap-4 items-center">
      <div class="w-14 h-14 bg-gray-200 rounded-full flex items-center justify-center text-xl">👤</div>
      <div class="flex-1">
        <div class="font-bold">{{ $s->name }}</div>
        <div class="text-xs text-gray-500">{{ $s->nisn }} • {{ $s->schoolClass->name ?? '-' }}</div>
        <div class="mt-2 flex gap-2">
          <a href="{{ route('admin.students.enroll.page',$s) }}" class="text-xs bg-black text-white px-3 py-1.5 rounded-lg">Enroll Kamera</a>
          <span class="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded">Belum ada wajah</span>
        </div>
      </div>
    </div>
    @endforeach
  </div>
  {{ $students->links() }}
</div>
<script>
fetch('{{ route('admin.students.enroll.stats') }}').then(r=>r.json()).then(d=>{
  document.getElementById('enroll-stats').innerText = d.enrolled + '/' + d.total + ' ('+d.percent+'%) ter-enroll';
});
</script>
@endsection

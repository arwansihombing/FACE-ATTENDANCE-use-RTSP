<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>@yield('title','Face Attendance v2')</title>
<script src="https://cdn.tailwindcss.com"></script>
@vite(['resources/js/app.js'])
</head><body class="bg-gray-50 min-h-screen">
<nav class="bg-white border-b px-6 py-3 flex justify-between"><span class="font-bold">Face Attendance v2 🚀</span><span>{{ auth()->user()->name ?? '' }}</span></nav>
<main class="p-6 max-w-7xl mx-auto">@yield('content')</main>
</body></html>

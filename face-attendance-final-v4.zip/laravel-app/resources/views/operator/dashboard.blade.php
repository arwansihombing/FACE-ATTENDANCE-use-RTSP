@extends('layouts.cms')
@section('title','Operator Dashboard')
@section('content')
<div class="max-w-7xl mx-auto space-y-4">
  <div class="flex justify-between items-center">
    <div>
      <h1 class="text-2xl font-black">Gerbang: {{ auth('operator')->user()->gate->name ?? 'Gerbang' }}</h1>
      <p class="text-sm text-gray-500">Operator: {{ auth('operator')->user()->name }} • {{ now()->format('d M Y H:i') }}</p>
    </div>
    <div class="flex gap-2">
      <a href="{{ route('operator.call') }}" class="bg-black text-white px-5 py-2.5 rounded-xl font-bold text-sm">📢 Layar Panggil Fullscreen</a>
      <form method="POST" action="{{ route('operator.logout') ?? '/operator/logout' }}">@csrf<button class="border px-4 py-2.5 rounded-xl text-sm">Logout</button></form>
    </div>
  </div>

  <div class="grid md:grid-cols-3 gap-4">
    <div class="md:col-span-2 bg-white rounded-2xl shadow p-5">
      <h2 class="font-bold mb-3">Antrian Panggil Realtime</h2>
      <div id="queue" class="space-y-2 max-h-[60vh] overflow-y-auto"></div>
      <div class="mt-4 flex gap-2">
        <button onclick="popNext()" class="bg-green-600 text-white px-4 py-2 rounded-xl text-sm font-bold">▶ Panggil Berikutnya (TTS)</button>
        <button onclick="loadQueue()" class="border px-4 py-2 rounded-xl text-sm">Refresh</button>
        <label class="flex items-center gap-2 text-sm ml-auto"><input type="checkbox" id="auto-tts" checked> Auto TTS</label>
      </div>
    </div>
    <div class="bg-white rounded-2xl shadow p-5">
      <h2 class="font-bold mb-3">Absen Hari Ini ({{ $today->count() }})</h2>
      <div class="space-y-2 max-h-[60vh] overflow-y-auto text-sm">
        @foreach($today as $a)
          <div class="flex justify-between border-b py-2">
            <span><b>{{ $a->student->name ?? '-' }}</b><br><span class="text-xs text-gray-500">{{ $a->student->schoolClass->name ?? '' }} • {{ $a->verified_at?->format('H:i') }}</span></span>
            <span class="text-xs px-2 py-1 rounded-full {{ $a->status->value=='late'?'bg-yellow-100 text-yellow-700':'bg-green-100 text-green-700' }}">{{ $a->status->value }}</span>
          </div>
        @endforeach
      </div>
    </div>
  </div>
</div>

<script>
let voices=[];
function loadVoices(){ voices=speechSynthesis.getVoices(); }
speechSynthesis.onvoiceschanged=loadVoices; loadVoices();

function speak(text){
  if(!document.getElementById('auto-tts').checked) return;
  const u=new SpeechSynthesisUtterance(text);
  u.lang='id-ID';
  // Cari suara Indonesia
  const idVoice=voices.find(v=>v.lang.includes('id')) || voices[0];
  if(idVoice) u.voice=idVoice;
  u.rate=0.95; u.pitch=1;
  speechSynthesis.cancel(); speechSynthesis.speak(u);
}

async function loadQueue(){
  const res=await fetch('{{ route('operator.queue') }}'); const data=await res.json();
  const el=document.getElementById('queue');
  if(data.length==0){ el.innerHTML='<div class="text-center text-gray-400 py-10">Antrian kosong - menunggu siswa...</div>'; return; }
  el.innerHTML=data.map((a,i)=>`
    <div class="flex justify-between items-center border rounded-xl p-3 ${i==0?'bg-yellow-50 border-yellow-300':''}">
      <div><div class="font-bold">${a.student_name}</div><div class="text-xs text-gray-500">${a.nisn} • ${a.class} • ${a.time} • conf ${(a.confidence*100).toFixed(1)}%</div></div>
      <button onclick="callOne(${a.id},'${a.student_name}','${a.class}')" class="bg-black text-white text-xs px-3 py-1.5 rounded-lg">Panggil</button>
    </div>
  `).join('');
}

function callOne(id,name,kelas){
  speak(`${name}, silahkan masuk, kelas ${kelas}`);
  fetch(`/operator/queue/${id}/called`,{method:'POST',headers:{'X-CSRF-TOKEN':'{{ csrf_token() }}'}});
  setTimeout(loadQueue,1200);
}

async function popNext(){
  const r=await fetch('/operator/queue/pop',{method:'POST',headers:{'X-CSRF-TOKEN':'{{ csrf_token() }}'}}).then(r=>r.json());
  if(!r.ok){ alert(r.message); return; }
  speak(r.data.tts_text);
}

loadQueue(); setInterval(loadQueue,3000);

// Reverb listener
try{
  if(window.Echo){
    const gateId={{ auth('operator')->user()->gate_id ?? 1 }};
    window.Echo.channel('gate.'+gateId).listen('StudentVerified',(e)=>{
      const audio=new Audio('https://cdn.pixabay.com/download/audio/2021/08/04/audio_0625c1539c.mp3?filename=notification-sound-7062.mp3');
      audio.volume=0.3; audio.play().catch(()=>{});
      loadQueue();
      speak(`${e.student} terdeteksi, silahkan masuk`);
    });
  }
}catch(e){ console.log('Echo error',e); }
</script>
@endsection

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Layar Panggil - {{ $gate->name ?? 'Gerbang' }}</title>
<script src="https://cdn.tailwindcss.com"></script>
@vite(['resources/js/app.js'])
<style>
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@700;800&display=swap');
  body{ font-family:'Plus Jakarta Sans',sans-serif; }
  .animate-pop{ animation: pop 0.6s cubic-bezier(.175,.885,.32,1.275); }
  @keyframes pop{ 0%{transform:scale(0.8);opacity:0} 100%{transform:scale(1);opacity:1} }
</style>
</head>
<body class="bg-[#0a0a0a] text-white min-h-screen flex flex-col overflow-hidden">
  <header class="flex justify-between items-center p-6 border-b border-white/10">
    <div class="flex items-center gap-4">
      <div class="w-12 h-12 bg-white text-black rounded-full flex items-center justify-center font-black text-xl">{{ substr($gate->name ?? 'G',0,1) }}</div>
      <div><div class="font-black text-xl leading-none">{{ $gate->name ?? 'Gerbang A' }}</div><div class="text-xs text-white/60">{{ now()->format('d M Y') }} • Layar Panggil Otomatis</div></div>
    </div>
    <div class="flex items-center gap-4">
      <div id="clock" class="text-3xl font-black tracking-tight">--:--:--</div>
      <a href="{{ route('operator.dashboard') }}" class="bg-white/10 hover:bg-white/20 px-4 py-2 rounded-full text-sm">Dashboard</a>
    </div>
  </header>

  <main class="flex-1 flex">
    <!-- Main Call Display -->
    <div class="flex-1 flex flex-col items-center justify-center p-10 text-center">
      <div class="text-white/40 text-sm tracking-[0.3em] uppercase mb-6">Sedang Memanggil</div>
      <div id="main-card" class="animate-pop">
        <div class="text-[12vw] md:text-[9vw] font-black leading-[0.9] tracking-tighter" id="student-name">Menunggu...</div>
        <div class="mt-6 text-[4vw] md:text-[3vw] font-bold text-white/60" id="student-class">-</div>
        <div class="mt-8 inline-flex items-center gap-3 bg-white text-black px-8 py-4 rounded-full text-xl font-black" id="status-badge">
          <span class="w-3 h-3 bg-green-500 rounded-full animate-pulse"></span> <span id="status-text">Siap</span>
        </div>
      </div>
      <div class="mt-12 flex gap-3">
        <button onclick="toggleTTS()" id="tts-btn" class="bg-white text-black px-6 py-3 rounded-full font-bold">🔊 TTS ON</button>
        <button onclick="popNext()" class="bg-white/10 border border-white/20 px-6 py-3 rounded-full font-bold">▶ Panggil Berikutnya</button>
        <button onclick="repeatLast()" class="bg-white/10 border border-white/20 px-6 py-3 rounded-full">🔁 Ulangi</button>
      </div>
    </div>

    <!-- Side Queue -->
    <div class="w-[360px] border-l border-white/10 bg-white/[0.03] p-6 flex flex-col">
      <div class="flex justify-between items-center mb-4"><h3 class="font-bold">Antrian</h3><span id="queue-count" class="text-xs bg-white/10 px-2 py-1 rounded-full">0</span></div>
      <div id="side-queue" class="flex-1 space-y-2 overflow-y-auto"></div>
      <div class="mt-4 p-3 bg-white/5 rounded-xl text-xs text-white/50">
        <div>🔊 TTS: Browser Speech API id-ID</div>
        <div>📡 WebSocket: Reverb gate.{{ $gate->id ?? 1 }}</div>
        <div>⏱️ Auto call: <input type="checkbox" id="auto-call" checked> <label>aktif (3 detik)</label></div>
      </div>
    </div>
  </main>

<script>
let voices=[], lastCalled=null, ttsEnabled=true, queueCache=[];
function loadVoices(){ voices=speechSynthesis.getVoices(); }
speechSynthesis.onvoiceschanged=loadVoices; loadVoices();

function speak(text){
  if(!ttsEnabled) return;
  speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(text);
  u.lang='id-ID';
  const idV=voices.find(v=>v.lang.toLowerCase().includes('id')) || voices.find(v=>v.lang.includes('en')) || voices[0];
  if(idV) u.voice=idV;
  u.rate=0.92; u.pitch=1.05; u.volume=1;
  speechSynthesis.speak(u);
  document.getElementById('status-text').innerText='Memanggil...';
  setTimeout(()=>{ document.getElementById('status-text').innerText='Siap'; }, 3000);
}

function toggleTTS(){
  ttsEnabled=!ttsEnabled;
  document.getElementById('tts-btn').innerText= ttsEnabled ? '🔊 TTS ON' : '🔇 TTS OFF';
  document.getElementById('tts-btn').className= ttsEnabled ? 'bg-white text-black px-6 py-3 rounded-full font-bold' : 'bg-red-500 text-white px-6 py-3 rounded-full font-bold';
}

async function fetchQueue(){
  const data=await fetch('/operator/queue/json').then(r=>r.json());
  queueCache=data;
  document.getElementById('queue-count').innerText=data.length;
  document.getElementById('side-queue').innerHTML=data.map((a,i)=>`
    <div class="p-3 rounded-xl ${i==0?'bg-white text-black':'bg-white/10'} flex justify-between items-center">
      <div><div class="font-bold text-sm leading-tight">${a.student_name}</div><div class="text-xs opacity-60">${a.class} • ${a.time}</div></div>
      <button onclick="callSpecific('${a.student_name}','${a.class}',${a.id})" class="text-xs bg-black/20 px-2 py-1 rounded-full">Panggil</button>
    </div>
  `).join('') || '<div class="text-white/30 text-sm text-center py-10">Antrian kosong</div>';
}

function callSpecific(name,kelas,id){
  lastCalled={name,kelas,id, text:`${name}, kelas ${kelas}, silahkan masuk`};
  document.getElementById('student-name').innerText=name;
  document.getElementById('student-class').innerText=kelas ? `Kelas ${kelas}` : '';
  document.getElementById('main-card').classList.remove('animate-pop'); void document.getElementById('main-card').offsetWidth; document.getElementById('main-card').classList.add('animate-pop');
  speak(lastCalled.text);
  if(id) fetch(`/operator/queue/${id}/called`,{method:'POST',headers:{'X-CSRF-TOKEN':'{{ csrf_token() }}'}});
}

async function popNext(){
  const r=await fetch('/operator/queue/pop',{method:'POST',headers:{'X-CSRF-TOKEN':'{{ csrf_token() }}'}}).then(r=>r.json());
  if(!r.ok){ document.getElementById('student-name').innerText='Antrian Kosong'; speak('Antrian kosong'); return; }
  callSpecific(r.data.student_name, r.data.class, r.data.id);
}

function repeatLast(){ if(lastCalled) speak(lastCalled.text); }

setInterval(fetchQueue,2500);
setInterval(()=>{ document.getElementById('clock').innerText=new Date().toLocaleTimeString('id-ID',{hour12:false}); },1000);
fetchQueue();

// Reverb auto-call
try{
  if(window.Echo){
    const gateId={{ $gate->id ?? 1 }};
    window.Echo.channel('gate.'+gateId).listen('StudentVerified',(e)=>{
      fetchQueue();
      if(document.getElementById('auto-call').checked){
        setTimeout(()=>{ callSpecific(e.student, '', null); }, 800);
      }
    });
  }
}catch(e){ console.log(e); }

// Keyboard shortcut: Space = panggil berikutnya
document.addEventListener('keydown',(ev)=>{ if(ev.code==='Space'){ ev.preventDefault(); popNext(); } });
</script>
</body>
</html>

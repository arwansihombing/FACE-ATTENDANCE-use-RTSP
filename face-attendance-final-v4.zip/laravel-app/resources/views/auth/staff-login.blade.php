@extends('layouts.cms')
@section('content')
<div class="max-w-md mx-auto bg-white p-8 rounded-2xl shadow">
<h1 class="text-2xl font-bold mb-6">Staff Login</h1>
<form method="POST" action="/login">@csrf
<input name="email" type="email" placeholder="Email" class="w-full border p-3 rounded mb-3" required>
<input name="password" type="password" placeholder="Password" class="w-full border p-3 rounded mb-4" required>
<button class="w-full bg-black text-white py-3 rounded-xl">Masuk</button>
</form></div>@endsection

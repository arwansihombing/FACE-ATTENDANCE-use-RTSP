@extends('layouts.guest')
@section('content')
<div class="bg-white p-8 rounded-2xl shadow max-w-md w-full">
<h1 class="text-2xl font-black mb-1">Operator Gate</h1><p class="text-sm text-gray-500 mb-6">Login untuk gerbang Anda</p>
<form method="POST" action="{{ route('operator.login.attempt') }}">@csrf
<input name="username" placeholder="Username" class="w-full border p-3 rounded-xl mb-3" required>
<input name="password" type="password" placeholder="Password" class="w-full border p-3 rounded-xl mb-4" required>
<button class="w-full bg-black text-white py-3 rounded-xl font-bold">Masuk Gerbang</button>
</form>
</div>
@endsection

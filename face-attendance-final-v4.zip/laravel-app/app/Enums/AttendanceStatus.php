<?php
namespace App\Enums;
enum AttendanceStatus: string {
  case Present='present'; case Late='late'; case Early='early'; case Absent='absent'; case Review='review';
}

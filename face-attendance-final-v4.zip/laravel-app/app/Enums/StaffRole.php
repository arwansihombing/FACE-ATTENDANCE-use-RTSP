<?php
namespace App\Enums;
enum StaffRole: string {
  case Admin = 'admin';
  case IT = 'it';
  case GuruBK = 'guru_bk';
  case Kepsek = 'kepsek';
  public function label(): string { return match($this){
    self::Admin=>'Admin', self::IT=>'IT Support', self::GuruBK=>'Guru BK', self::Kepsek=>'Kepala Sekolah'
  };}
}

<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Http;

class StudentEnrollController extends Controller {
  public function index(Request $r){
    $q = Student::with('schoolClass')->whereNull('face_embedding');
    if($r->search) $q->where('name','ilike','%'.$r->search.'%');
    $students = $q->paginate(20);
    return view('admin.students-enroll', compact('students'));
  }

  public function capturePage(Student $student){
    return view('admin.students-enroll-capture', compact('student'));
  }

  public function enroll(Request $r, Student $student){
    $r->validate([
      'photo'=>'required|image|max:5120',
      'embedding'=>'required|array|size:512'
    ]);

    // Save photo
    $path = $r->file('photo')->store('students/'.$student->id, 'public');

    // Save embedding directly (from Python worker or JS)
    $student->update([
      'photo_path'=>$path,
      'face_embedding'=> $r->embedding, // pgvector will cast
      'embedding_version'=> config('face.version',1),
    ]);

    // Optional: push to python worker to verify quality
    return response()->json(['ok'=>true,'message'=>'Wajah berhasil di-enroll','photo'=>$path]);
  }

  public function bulkEnrollStatus(){
    $total = Student::count();
    $enrolled = Student::whereNotNull('face_embedding')->count();
    return response()->json(['total'=>$total,'enrolled'=>$enrolled,'percent'=> $total? round($enrolled/$total*100):0 ]);
  }
}

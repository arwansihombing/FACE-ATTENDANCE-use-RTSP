<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\StudentsImport;
use App\Exports\StudentsTemplateExport;
use App\Models\SchoolClass;

class StudentImportController extends Controller {
  public function template(){ return Excel::download(new StudentsTemplateExport, 'template_import_siswa.xlsx'); }

  public function show(){
    $classes = SchoolClass::with(['level','major'])->get();
    return view('admin.students-import', compact('classes'));
  }

  public function import(Request $r){
    $r->validate([
      'school_class_id'=>'required|exists:school_classes,id',
      'file'=>'required|mimes:xlsx,xls,csv|max:5120'
    ]);
    $import = new StudentsImport($r->school_class_id);
    Excel::import($import, $r->file('file'));

    $failures = $import->failures();
    if($failures->isNotEmpty()){
      return back()->with('import_failures',$failures)->with('success', 'Import selesai dengan beberapa error');
    }
    return back()->with('success','Berhasil import siswa!');
  }
}

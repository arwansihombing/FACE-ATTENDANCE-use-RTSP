<?php
namespace App\Http\Controllers\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request; use Illuminate\Support\Facades\Auth;
class StaffLoginController extends Controller {
  public function show(){ return view('auth.staff-login'); }
  public function login(Request $r){
    $r->validate(['email'=>'required|email','password'=>'required']);
    $r->ensureIsNotRateLimited();
    if(Auth::attempt($r->only('email','password'), $r->boolean('remember'))){
      if(!Auth::user()->is_active){ Auth::logout(); return back()->withErrors(['email'=>'Akun nonaktif']); }
      $r->session()->regenerate();
      return redirect()->intended(match(Auth::user()->role->value){
        'admin'=>'/admin','it'=>'/it','guru_bk'=>'/guru-bk','kepsek'=>'/kepsek', default=>'/'
      });
    }
    $r->hitRateLimiter();
    return back()->withErrors(['email'=>'Kredensial salah']);
  }
  public function logout(Request $r){ Auth::logout(); $r->session()->invalidate(); $r->session()->regenerateToken(); return redirect('/login'); }
}

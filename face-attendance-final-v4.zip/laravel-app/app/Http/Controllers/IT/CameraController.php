<?php
namespace App\Http\Controllers\IT;
use App\Http\Controllers\Controller;
use App\Models\Camera;
use App\Models\Gate;
use Illuminate\Http\Request;

class CameraController extends Controller {
  public function index(){ 
    $cameras = Camera::with('gate')->latest()->paginate(15);
    $gates = Gate::all();
    return view('it.cameras', compact('cameras','gates'));
  }
  public function store(Request $r){
    $data=$r->validate([
      'gate_id'=>'required|exists:gates,id',
      'name'=>'required|string|max:50',
      'rtsp_url'=>'required|string',
    ]);
    $data['status']='offline';
    Camera::create($data);
    return back()->with('success','Kamera ditambahkan');
  }
  public function update(Request $r, Camera $camera){
    $camera->update($r->validate(['name'=>'required','rtsp_url'=>'required']));
    return back()->with('success','Kamera diupdate');
  }
  public function destroy(Camera $camera){ $camera->delete(); return back()->with('success','Kamera dihapus'); }
  public function test(Camera $camera){
    // Call python worker health check
    return response()->json(['message'=>'Test frame requested','camera_id'=>$camera->id,'note'=>'Cek python-worker logs']);
  }
}

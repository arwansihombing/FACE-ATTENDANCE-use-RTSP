<?php
namespace App\Http\Controllers\IT;
use App\Http\Controllers\Controller;
use App\Models\Camera;
use App\Models\Gate;
use App\Models\Attendance;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller {
  public function index(){
    $gates = Gate::withCount('cameras')->get();
    $cameras = Camera::with('gate')->get();
    $todayCount = Attendance::whereDate('date', today())->count();
    $staleCameras = Camera::stale(2)->count();
    
    // Redis queue length
    $queueLen = 0;
    try { $queueLen = Redis::llen('call_queue'); } catch(\Exception $e){}

    // GPU stats from last heartbeat payload (if any)
    $stats = [
      'total_cameras'=>$cameras->count(),
      'online'=>$cameras->where('status','online')->count(),
      'offline'=>$cameras->where('status','offline')->count(),
      'stale'=>$staleCameras,
      'queue'=>$queueLen,
      'today'=>$todayCount,
    ];

    return view('it.dashboard', compact('gates','cameras','stats'));
  }

  public function camerasJson(){
    $cameras = Camera::with('gate')->get()->map(fn($c)=>[
      'id'=>$c->id,
      'name'=>$c->name,
      'gate'=>$c->gate->name ?? '-',
      'status'=>$c->status,
      'is_active'=>$c->is_active,
      'last_heartbeat'=>$c->last_heartbeat_at?->diffForHumans(),
      'rtsp'=> substr($c->rtsp_url,0,30).'...',
      'stale'=> $c->last_heartbeat_at ? $c->last_heartbeat_at->lt(now()->subMinutes(2)) : true,
    ]);
    return response()->json($cameras);
  }

  public function toggle(Camera $camera){
    $camera->update(['is_active'=> !$camera->is_active]);
    return back()->with('success','Status kamera diupdate');
  }
}

<?php
namespace App\Http\Controllers\Operator;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class SelectGateController extends Controller {
  public function login(Request $r){
    $r->validate(['username'=>'required','password'=>'required']);
    if(Auth::guard('operator')->attempt($r->only('username','password'))){
      $op=Auth::guard('operator')->user();
      if(!$op->is_active){ Auth::guard('operator')->logout(); return back()->withErrors(['username'=>'Operator nonaktif']); }
      $r->session()->regenerate();
      return redirect()->route('operator.dashboard');
    }
    return back()->withErrors(['username'=>'Login operator salah']);
  }
  public function logout(Request $r){
    Auth::guard('operator')->logout();
    $r->session()->invalidate(); $r->session()->regenerateToken();
    return redirect()->route('operator.login');
  }
}

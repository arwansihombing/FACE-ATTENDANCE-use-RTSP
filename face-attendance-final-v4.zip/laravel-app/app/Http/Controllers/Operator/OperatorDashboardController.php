<?php
namespace App\Http\Controllers\Operator;
use App\Http\Controllers\Controller;
use App\Models\Attendance; use Illuminate\Support\Facades\Redis;
class OperatorDashboardController extends Controller {
  public function index(){
    $gateId=auth('operator')->user()->gate_id;
    $todayAttendances=Attendance::with('student')->where('gate_id',$gateId)->whereDate('date',today())->latest()->limit(50)->get();
    return view('operator.dashboard',compact('todayAttendances'));
  }
  public function callQueue(){
    $items=Redis::lrange('call_queue',0,20);
    return response()->json($items);
  }
}

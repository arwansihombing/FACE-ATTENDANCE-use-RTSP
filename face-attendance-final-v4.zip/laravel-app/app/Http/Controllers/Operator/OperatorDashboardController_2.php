<?php
namespace App\Http\Controllers\Operator;
use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Services\CallQueueService;
use Illuminate\Support\Facades\Redis;
use Illuminate\Http\Request;

class OperatorDashboardController extends Controller {
  public function index(){
    $gateId=auth('operator')->user()->gate_id;
    $today=Attendance::with(['student.schoolClass'])->where('gate_id',$gateId)->whereDate('date',today())->latest()->limit(100)->get();
    return view('operator.dashboard', compact('today'));
  }

  public function queueJson(){
    $gateId=auth('operator')->user()->gate_id;
    try{
      $ids=Redis::lrange('call_queue:'.$gateId,0,50);
    } catch(\Exception $e){ $ids=[]; }
    if(empty($ids)){
      // fallback global
      try{ $ids=Redis::lrange('call_queue',0,50); } catch(\Exception $e){ $ids=[]; }
    }
    $attendances=Attendance::with('student')->whereIn('id',$ids)->get()->sortBy(fn($a)=>array_search($a->id,$ids))->values();
    return response()->json($attendances->map(fn($a)=>[
      'id'=>$a->id,
      'student_name'=>$a->student->name ?? 'Siswa',
      'nisn'=>$a->student->nisn ?? '',
      'class'=>$a->student->schoolClass->name ?? '',
      'time'=>$a->verified_at?->format('H:i:s'),
      'status'=>$a->status->value,
      'confidence'=>$a->confidence,
    ]));
  }

  public function callPage(){
    $gate=auth('operator')->user()->gate;
    return view('operator.call-page', compact('gate'));
  }

  public function markCalled(Request $r, Attendance $attendance, CallQueueService $svc){
    // Hapus dari queue
    $gateId=auth('operator')->user()->gate_id;
    try{
      Redis::lrem('call_queue:'.$gateId,0,$attendance->id);
      Redis::lrem('call_queue',0,$attendance->id);
    }catch(\Exception $e){}
    return response()->json(['ok'=>true]);
  }

  public function popNext(CallQueueService $svc){
    $gateId=auth('operator')->user()->gate_id;
    $nextId=null;
    try{ $nextId=Redis::lpop('call_queue:'.$gateId); }catch(\Exception $e){}
    if(!$nextId){
      try{ $nextId=Redis::lpop('call_queue'); }catch(\Exception $e){}
    }
    if(!$nextId) return response()->json(['ok'=>false,'message'=>'Antrian kosong']);
    $att=Attendance::with('student.schoolClass')->find($nextId);
    return response()->json(['ok'=>true,'data'=>[
      'id'=>$att->id,
      'student_name'=>$att->student->name,
      'class'=>$att->student->schoolClass->name ?? '',
      'tts_text'=> $att->student->name.' silahkan masuk, kelas '.$att->student->schoolClass->name
    ]]);
  }
}

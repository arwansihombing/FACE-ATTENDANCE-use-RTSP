<?php
namespace App\Http\Controllers\Internal;
use App\Http\Controllers\Controller;
use App\Models\Camera; use Illuminate\Http\Request;
class HeartbeatController extends Controller {
  public function store(Request $r){
    $data=$r->validate(['camera_id'=>'required|integer','status'=>'string']);
    Camera::where('id',$data['camera_id'])->update(['last_heartbeat_at'=>now(),'status'=>$data['status']]);
    return response()->json(['ok'=>true]);
  }
}

<?php
namespace App\Http\Controllers\Internal;
use App\Http\Controllers\Controller;
use App\Services\AttendanceService;
use Illuminate\Http\Request;
class AttendanceController extends Controller {
  public function store(Request $r, AttendanceService $svc){
    $data=$r->validate(['student_id'=>'required|integer','gate_id'=>'nullable|integer','camera_id'=>'nullable|integer','confidence'=>'required|numeric','snapshot_path'=>'nullable|string']);
    $att=$svc->record($data['student_id'], $data);
    return response()->json(['ok'=>true,'id'=>$att->id]);
  }
}

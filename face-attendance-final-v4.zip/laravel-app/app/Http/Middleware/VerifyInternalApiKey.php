<?php
namespace App\Http\Middleware;
use Closure; use Illuminate\Support\Facades\Hash;
class VerifyInternalApiKey {
  public function handle($request, Closure $next){
    $key=$request->header('X-Internal-Key');
    $sig=$request->header('X-Internal-Signature');
    $expected=config('services.internal.key');
    $secret=config('services.internal.secret');
    if($key!==$expected) abort(401,'Invalid internal key');
    $payload=$request->getContent();
    $calc=hash_hmac('sha256',$payload,$secret);
    if(!hash_equals($calc,$sig ?? '')) abort(401,'Invalid signature');
    return $next($request);
  }
}

<?php
namespace App\Http\Middleware;
use Closure; use App\Enums\StaffRole;
class EnsureStaffRole {
  public function handle($request, Closure $next, ...$roles){
    $user=$request->user();
    if(!$user || !in_array($user->role->value, $roles)) abort(403,'Role tidak diizinkan');
    if(!$user->is_active) abort(403,'Akun nonaktif');
    return $next($request);
  }
}

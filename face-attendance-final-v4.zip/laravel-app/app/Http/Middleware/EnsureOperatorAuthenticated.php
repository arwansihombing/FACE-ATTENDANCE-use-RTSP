<?php
namespace App\Http\Middleware;
use Closure;
class EnsureOperatorAuthenticated {
  public function handle($request, Closure $next){
    if(!auth('operator')->check()) return redirect()->route('operator.login');
    if(!auth('operator')->user()->is_active) { auth('operator')->logout(); abort(403,'Operator nonaktif'); }
    return $next($request);
  }
}

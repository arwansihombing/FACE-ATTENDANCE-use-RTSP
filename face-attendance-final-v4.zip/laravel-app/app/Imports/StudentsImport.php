<?php
namespace App\Imports;
use App\Models\Student;
use App\Models\SchoolClass;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\SkipsFailures;

class StudentsImport implements ToModel, WithHeadingRow, WithValidation, SkipsOnFailure {
  use SkipsFailures;
  public function __construct(private int $classId) {}
  public function model(array $row){
    return new Student([
      'nisn'=> trim($row['nisn']),
      'name'=> trim($row['nama']),
      'school_class_id'=> $this->classId,
      'is_active'=> true,
    ]);
  }
  public function rules(): array {
    return [
      'nisn'=>'required|digits:10|unique:students,nisn',
      'nama'=>'required|string|min:3|max:100',
    ];
  }
}

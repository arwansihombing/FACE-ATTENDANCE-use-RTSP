<?php
namespace App\Services;
use App\Models\Attendance; use App\Models\Student; use App\Enums\AttendanceStatus; use App\Events\StudentVerified; use Carbon\Carbon;
class AttendanceService {
  public function __construct(private CallQueueService $queue, private SchoolCalendarService $calendar){}
  public function record(int $studentId, array $ctx): Attendance {
    $today=now()->toDateString();
    $existing=Attendance::where('student_id',$studentId)->whereDate('date',$today)->whereIn('status',[AttendanceStatus::Present,AttendanceStatus::Late, AttendanceStatus::Early])->first();
    if($existing) return $existing;

    $schoolStart=Carbon::parse('07:00');
    $now=Carbon::now();
    $lateMinutes=$now->diffInMinutes($schoolStart,false); // negative = telat

    $status= match(true){
      $lateMinutes < -15 => AttendanceStatus::Late,
      $lateMinutes > 5 => AttendanceStatus::Early,
      default => AttendanceStatus::Present
    };

    $att=Attendance::create([
      'student_id'=>$studentId,
      'gate_id'=>$ctx['gate_id'] ?? null,
      'camera_id'=>$ctx['camera_id'] ?? null,
      'status'=>$status,
      'confidence'=>$ctx['confidence'] ?? 0,
      'late_minutes'=>$lateMinutes,
      'snapshot_path'=>$ctx['snapshot_path'] ?? null,
      'verified_at'=>now(),
      'date'=>$today,
    ]);
    $att->load('student.schoolClass');
    // Push ke antrian panggil
    $this->queue->push($att);
    StudentVerified::dispatch($att);
    return $att;
  }
}

<?php
namespace App\Services;
use Illuminate\Support\Facades\Redis;
class CallQueueService {
  public function push(int $attendanceId){ Redis::rpush('call_queue', $attendanceId); Redis::publish('gate-channel','new_call:'.$attendanceId); }
  public function pop(): ?int { return Redis::lpop('call_queue'); }
}

<?php
namespace App\Services;
use Illuminate\Support\Facades\Redis;
use App\Models\Attendance;

class CallQueueService {
  public function push(Attendance $att){
    $gateId=$att->gate_id ?? 0;
    try{
      // Push ke queue per gate + global fallback
      Redis::rpush('call_queue:'.$gateId, $att->id);
      Redis::rpush('call_queue', $att->id);
      Redis::expire('call_queue:'.$gateId, 3600*6);
      Redis::publish('gate.'.$gateId, json_encode([
        'event'=>'StudentVerified',
        'id'=>$att->id,
        'student'=>$att->student->name ?? 'Siswa',
        'time'=>now()->format('H:i:s')
      ]));
      // Broadcast Laravel event
      \App\Events\StudentVerified::dispatch($att);
    }catch(\Exception $e){
      \Log::error('CallQueue push failed: '.$e->getMessage());
    }
  }
  public function length(int $gateId=0): int {
    try{ return $gateId ? Redis::llen('call_queue:'.$gateId) : Redis::llen('call_queue'); }
    catch(\Exception $e){ return 0; }
  }
  public function clear(int $gateId=0){
    try{ Redis::del($gateId? 'call_queue:'.$gateId : 'call_queue'); }catch(\Exception $e){}
  }
}

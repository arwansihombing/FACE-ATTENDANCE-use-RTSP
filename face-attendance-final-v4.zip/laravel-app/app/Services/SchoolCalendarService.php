<?php
namespace App\Services;
use Carbon\Carbon;
class SchoolCalendarService {
  public function isSchoolDay(Carbon $date): bool {
    if($date->isWeekend()) return false;
    // TODO: cek AcademicCalendar table
    return true;
  }
  public function lateMinutes(Carbon $checkIn, Carbon $schoolStart): int {
    return $checkIn->diffInMinutes($schoolStart,false); // negative = late
  }
}

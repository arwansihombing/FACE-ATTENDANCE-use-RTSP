<?php
namespace App\Services;
use App\Models\Attendance; use App\Models\Student; use App\Enums\AttendanceStatus; use App\Events\StudentVerified;
class AttendanceService {
  public function record(int $studentId, array $ctx): Attendance {
    $today=now()->toDateString();
    // Idempoten: cegah dobel
    $existing=Attendance::where('student_id',$studentId)->whereDate('date',$today)->whereIn('status',[AttendanceStatus::Present,AttendanceStatus::Late])->first();
    if($existing) return $existing;

    $status=$this->determineStatus($ctx);
    $att=Attendance::create([
      'student_id'=>$studentId,
      'gate_id'=>$ctx['gate_id'] ?? null,
      'camera_id'=>$ctx['camera_id'] ?? null,
      'status'=>$status,
      'confidence'=>$ctx['confidence'] ?? 0,
      'late_minutes'=>$ctx['late_minutes'] ?? 0,
      'snapshot_path'=>$ctx['snapshot_path'] ?? null,
      'verified_at'=>now(),
      'date'=>$today,
    ]);
    StudentVerified::dispatch($att);
    return $att;
  }
  private function determineStatus(array $ctx): AttendanceStatus {
    $late=$ctx['late_minutes'] ?? 0;
    if($late>0) return AttendanceStatus::Late;
    if($late<0) return AttendanceStatus::Early;
    return AttendanceStatus::Present;
  }
}

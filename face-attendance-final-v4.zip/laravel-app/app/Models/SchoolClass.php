<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class SchoolClass extends Model { protected $table='school_classes'; protected $fillable=['level_id','major_id','name']; public function students(){ return $this->hasMany(Student::class); } }

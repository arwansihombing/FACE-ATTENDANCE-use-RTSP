<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Student extends Model {
  protected $fillable=['nisn','name','school_class_id','photo_path','face_embedding','embedding_version','is_active'];
  protected $casts=['face_embedding'=>'array','is_active'=>'boolean'];
  public function schoolClass(){ return $this->belongsTo(SchoolClass::class); }
  public function attendances(){ return $this->hasMany(Attendance::class); }
}

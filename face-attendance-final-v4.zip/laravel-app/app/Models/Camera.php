<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Camera extends Model {
  protected $fillable=['gate_id','name','rtsp_url','is_active','last_heartbeat_at','status'];
  protected $casts=['is_active'=>'boolean','last_heartbeat_at'=>'datetime'];
  public function gate(){ return $this->belongsTo(Gate::class); }
  public function scopeStale($q,$minutes=2){ return $q->where('last_heartbeat_at','<',now()->subMinutes($minutes)); }
}

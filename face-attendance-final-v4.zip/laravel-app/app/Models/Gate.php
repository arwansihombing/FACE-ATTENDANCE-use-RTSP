<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Gate extends Model { protected $fillable=['name','location','is_active']; protected $casts=['is_active'=>'boolean']; public function cameras(){ return $this->hasMany(Camera::class); } }

<?php
namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;
class Operator extends Authenticatable {
  protected $table='operators';
  protected $guard='operator';
  protected $fillable=['name','username','password','gate_id','is_active'];
  protected $casts=['is_active'=>'boolean','password'=>'hashed'];
  public function gate(){ return $this->belongsTo(Gate::class); }
}

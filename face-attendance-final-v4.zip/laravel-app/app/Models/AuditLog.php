<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class AuditLog extends Model { protected $fillable=['user_type','user_id','action','payload','ip']; protected $casts=['payload'=>'array']; }

<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use App\Enums\AttendanceStatus;
class Attendance extends Model {
  protected $fillable=['student_id','gate_id','camera_id','status','confidence','late_minutes','snapshot_path','verified_at','date'];
  protected $casts=['status'=>AttendanceStatus::class,'confidence'=>'float','verified_at'=>'datetime','date'=>'date'];
  public function student(){ return $this->belongsTo(Student::class); }
  // Idempoten: satu siswa satu hari satu status present/late
  public static function booted(){ static::creating(function($m){ $m->date = $m->date ?? now()->toDateString(); }); }
}

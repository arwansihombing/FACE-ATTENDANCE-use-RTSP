<?php
namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Enums\StaffRole;
use Illuminate\Notifications\Notifiable;
class User extends Authenticatable {
  use Notifiable;
  protected $fillable=['name','email','password','role','is_active'];
  protected $hidden=['password','remember_token'];
  protected $casts=['role'=>StaffRole::class,'is_active'=>'boolean','password'=>'hashed'];
  public function scopeActive($q){ return $q->where('is_active',true); }
}

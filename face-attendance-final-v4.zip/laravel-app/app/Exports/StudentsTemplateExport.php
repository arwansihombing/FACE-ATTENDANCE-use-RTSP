<?php
namespace App\Exports;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class StudentsTemplateExport implements FromArray, WithHeadings, WithStyles {
  public function array(): array {
    return [
      ['1234567890','Budi Santoso'],
      ['1234567891','Siti Aminah'],
    ];
  }
  public function headings(): array { return ['nisn','nama']; }
  public function styles(Worksheet $sheet){ return [1=>['font'=>['bold'=>true]]]; }
}

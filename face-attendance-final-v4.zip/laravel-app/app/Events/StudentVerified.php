<?php
namespace App\Events;
use App\Models\Attendance; use Illuminate\Broadcasting\Channel; use Illuminate\Broadcasting\InteractsWithSockets; use Illuminate\Contracts\Broadcasting\ShouldBroadcast; use Illuminate\Foundation\Events\Dispatchable;
class StudentVerified implements ShouldBroadcast {
  use Dispatchable, InteractsWithSockets;
  public function __construct(public Attendance $attendance){}
  public function broadcastOn(){ return new Channel('gate.'.$this->attendance->gate_id); }
  public function broadcastWith(){ return ['id'=>$this->attendance->id,'student'=>$this->attendance->student->name,'time'=>now()->format('H:i:s')]; }
}

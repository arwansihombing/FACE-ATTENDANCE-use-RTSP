import hmac, hashlib, json, httpx
from config import Config
def send_attendance(payload: dict):
  body=json.dumps(payload)
  sig=hmac.new(Config.SECRET.encode(), body.encode(), hashlib.sha256).hexdigest()
  headers={'X-Internal-Key':Config.KEY,'X-Internal-Signature':sig,'Content-Type':'application/json'}
  try:
    r=httpx.post(f"{Config.INTERNAL_URL}/attendance", content=body, headers=headers, timeout=5)
    print("Attendance sent:", r.status_code, r.text[:200])
  except Exception as e:
    print("Failed send:", e)

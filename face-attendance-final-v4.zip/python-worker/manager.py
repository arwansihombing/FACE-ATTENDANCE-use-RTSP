import cv2, time, threading
from inference import FaceEngine
from ring_buffer import RingBuffer
from embeddings import search_embedding
from attendance_client import send_attendance
from config import Config
print("Starting Face Worker v2 - Improved")
engine=FaceEngine(use_gpu=True)
buffers={}
# Simplified main loop: one thread per camera, batch window 100ms
def camera_loop(cam):
  cap=cv2.VideoCapture(cam['rtsp'])
  buf=RingBuffer(25)
  while True:
    ret,frame=cap.read()
    if not ret:
      time.sleep(1); cap=cv2.VideoCapture(cam['rtsp']); continue
    buf.push(frame)
    faces=engine.get_faces(frame)
    for f in faces:
      emb=f.normed_embedding.tolist()
      match=search_embedding(emb, Config.CONF_ACCEPT)
      if match:
        print(f"Matched {match[1]} sim={match[2]:.3f}")
        send_attendance({'student_id':match[0],'gate_id':cam['gate_id'],'camera_id':cam['id'],'confidence':match[2],'snapshot_path':''})
    time.sleep(0.1)

threads=[]
for cam in Config.CAMERAS:
  t=threading.Thread(target=camera_loop, args=(cam,), daemon=True)
  t.start(); threads.append(t)

print(f"Running {len(threads)} cameras")
while True: time.sleep(10)

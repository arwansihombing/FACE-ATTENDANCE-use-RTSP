import os, json
from dotenv import load_dotenv
load_dotenv()
class Config:
  DB_HOST=os.getenv('DB_HOST','localhost')
  DB_NAME=os.getenv('DB_NAME','face_attendance')
  DB_USER=os.getenv('DB_USER','fa_user')
  DB_PASS=os.getenv('DB_PASS','fa_password')
  REDIS_HOST=os.getenv('REDIS_HOST','localhost')
  INTERNAL_URL=os.getenv('INTERNAL_API_URL','http://localhost:8000/internal')
  KEY=os.getenv('INTERNAL_API_KEY','change-me')
  SECRET=os.getenv('INTERNAL_API_SECRET','change-me')
  CONF_ACCEPT=float(os.getenv('CONF_ACCEPT','0.60'))
  CONF_REVIEW=float(os.getenv('CONF_REVIEW','0.45'))
  CAMERAS=json.loads(os.getenv('CAMERAS_JSON','[]'))

from fastapi import FastAPI, UploadFile, File
import cv2, numpy as np
from inference import FaceEngine
import os

app=FastAPI(title="Face Worker v2 - Enroll & Extract")
engine=None

def get_engine():
  global engine
  if engine is None:
    engine=FaceEngine(use_gpu=os.getenv('USE_GPU','1')=='1')
  return engine

@app.get("/health")
def health(): return {"status":"ok","model":"buffalo_l","gpu":True,"version":"v2-improved"}

@app.post("/extract")
async def extract_embedding(photo: UploadFile = File(...)):
  eng=get_engine()
  data=await photo.read()
  nparr=np.frombuffer(data, np.uint8)
  img=cv2.imdecode(nparr, cv2.IMREAD_COLOR)
  faces=eng.get_faces(img)
  if not faces:
    return {"ok":False,"error":"Wajah tidak terdeteksi","faces":0}
  # Ambil wajah terbesar
  faces=sorted(faces, key=lambda x: (x.bbox[2]-x.bbox[0])*(x.bbox[3]-x.bbox[1]), reverse=True)
  best=faces[0]
  return {
    "ok":True,
    "embedding": best.normed_embedding.tolist(),
    "det_score": float(best.det_score),
    "bbox": best.bbox.tolist(),
    "faces_detected": len(faces)
  }

@app.post("/enroll")
async def enroll(): return {"todo":"deprecated, use /extract"}

@app.get("/cameras/status")
def cameras_status():
  return {"cameras":"check manager.py logs","note":"Heartbeat dikirim via internal/heartbeat"}

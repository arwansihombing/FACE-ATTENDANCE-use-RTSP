from fastapi import FastAPI
app=FastAPI()
@app.get("/health")
def health(): return {"status":"ok","model":"buffalo_l","gpu":True}
@app.post("/enroll")
def enroll(): return {"todo":"implement enroll with snapshot"}

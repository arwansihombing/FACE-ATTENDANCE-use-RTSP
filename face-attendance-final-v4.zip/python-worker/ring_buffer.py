from collections import deque
class RingBuffer:
  def __init__(self, size=25): self.buf=deque(maxlen=size)
  def push(self, frame): self.buf.append(frame)
  def best(self): return self.buf[-1] if self.buf else None

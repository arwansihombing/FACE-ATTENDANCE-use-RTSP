import insightface, cv2, numpy as np
from insightface.app import FaceAnalysis
class FaceEngine:
  def __init__(self, use_gpu=True):
    self.app=FaceAnalysis(name='buffalo_l', providers=['CUDAExecutionProvider','CPUExecutionProvider'] if use_gpu else ['CPUExecutionProvider'])
    self.app.prepare(ctx_id=0 if use_gpu else -1, det_size=(640,640))
  def get_faces(self, frame):
    return self.app.get(frame)
  def cosine(self, a,b):
    return float(np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b)+1e-9))

import psycopg2
from config import Config
def search_embedding(vec, threshold=0.60):
  conn=psycopg2.connect(host=Config.DB_HOST, dbname=Config.DB_NAME, user=Config.DB_USER, password=Config.DB_PASS)
  cur=conn.cursor()
  # HNSW cosine similarity, embedding version 1
  cur.execute("SELECT id, name, 1 - (face_embedding <=> %s::vector) as sim FROM students WHERE face_embedding IS NOT NULL ORDER BY face_embedding <=> %s::vector LIMIT 5", (vec, vec))
  rows=cur.fetchall()
  cur.close(); conn.close()
  best=[r for r in rows if r[2]>=threshold]
  return best[0] if best else None

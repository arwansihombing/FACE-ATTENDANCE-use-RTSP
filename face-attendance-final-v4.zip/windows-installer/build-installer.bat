@echo off
echo Build EXE Installer
pip install customtkinter pyinstaller pillow
pyinstaller --onefile --windowed --name FaceAttendanceInstaller gui_installer.py --distpath ..\dist
echo Selesai - cek dist folder
pause

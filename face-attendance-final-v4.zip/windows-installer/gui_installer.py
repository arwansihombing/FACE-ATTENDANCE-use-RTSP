
import tkinter as tk
from tkinter import ttk, messagebox
import os, subprocess, sys, threading, webbrowser, shutil, time

class InstallerGUI:
    def __init__(self, root):
        self.root=root
        root.title("Face Attendance v4 - Setup")
        root.geometry("620x520")
        ttk.Label(root, text="Face Attendance v4", font=("Segoe UI", 22, "bold")).pack(pady=(20,5))
        ttk.Label(root, text="One Click Installer").pack()
        ttk.Separator(root).pack(fill='x', pady=15)
        self.status_var=tk.StringVar(value="Siap install...")
        self.progress=ttk.Progressbar(root, length=540, mode='determinate')
        self.progress.pack(pady=10)
        ttk.Label(root, textvariable=self.status_var).pack()
        self.log=tk.Text(root, height=14, font=("Consolas", 9))
        self.log.pack(padx=15, pady=10, fill='both')
        btn_frame=ttk.Frame(root)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Install Sekarang", command=self.start_install).grid(row=0,column=0,padx=5)
        ttk.Button(btn_frame, text="Buka Aplikasi", command=lambda: webbrowser.open("http://localhost:8000")).grid(row=0,column=1,padx=5)

    def log_msg(self, msg):
        self.log.insert('end', msg+"\n"); self.log.see('end'); self.root.update()
    def set_progress(self, val, status):
        self.progress['value']=val; self.status_var.set(status); self.root.update()
    def run_cmd(self, cmd):
        self.log_msg(f"> {cmd}")
        try:
            proc=subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            for line in proc.stdout:
                self.log_msg(line.strip())
            proc.wait(); return proc.returncode==0
        except Exception as e:
            self.log_msg(f"Error: {e}"); return False
    def start_install(self):
        threading.Thread(target=self.install_thread, daemon=True).start()
    def install_thread(self):
        self.set_progress(10, "Cek Docker...")
        has_docker=shutil.which("docker") is not None
        if not has_docker:
            messagebox.showwarning("Docker belum ada", "Install Docker Desktop dulu")
            return
        self.set_progress(50, "Build Docker...")
        self.run_cmd("docker compose up -d --build")
        self.set_progress(80, "Setup Laravel...")
        time.sleep(5)
        self.run_cmd("docker compose exec app php artisan key:generate --force")
        self.run_cmd("docker compose exec app php artisan migrate --seed --force")
        self.set_progress(100, "Selesai!")
        webbrowser.open("http://localhost:8000")
        messagebox.showinfo("Selesai", "Berhasil!")

if __name__=="__main__":
    root=tk.Tk()
    app=InstallerGUI(root)
    root.mainloop()

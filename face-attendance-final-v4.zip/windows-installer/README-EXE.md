# Windows EXE Installer

Cara build EXE:
1. pip install customtkinter pyinstaller pillow
2. python windows-installer/create_icon.py (buat icon.ico)
3. build-installer.bat
Hasil: dist/FaceAttendanceInstaller.exe dan FaceAttendanceSetup-v4.exe (butuh Inno Setup)

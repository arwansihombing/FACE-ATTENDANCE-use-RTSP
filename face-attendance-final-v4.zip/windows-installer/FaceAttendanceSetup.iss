#define MyAppName "Face Attendance v4"
#define MyAppVersion "4.0.0"
[Setup]
AppId={{FACE-ATTENDANCE-V4}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
DefaultDirName=C:\FaceAttendance
DefaultGroupName=Face Attendance
OutputDir=..\dist
OutputBaseFilename=FaceAttendanceSetup-v4
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
[Languages]
Name: "indonesian"; MessagesFile: "compiler:Languages\Indonesian.isl"
[Files]
Source: "..\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs; Excludes: ".git,dist,build,*.pyc"
[Icons]
Name: "{group}\Face Attendance"; Filename: "{app}\start.bat"; WorkingDir: "{app}"
Name: "{autodesktop}\Face Attendance"; Filename: "{app}\start.bat"; WorkingDir: "{app}"
[Run]
Filename: "{app}\start.bat"; Description: "Jalankan sekarang"; Flags: nowait postinstall skipifsilent shellexec
